({
    
    fetchRecords : function(component, objName) {
        console.log('objName = '+objName);
        var action = component.get("c.getMusterData");  
        action.setParams({            
            "ObjectName": objName
        });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                var records = response.getReturnValue();
                var enti = records.Entity;
                
                if(typeof enti == 'undefined') {
                    component.set("v.Entity", 'None');
                    component.set("v.OldEntity", 'None');
                }
                
                if(objName == '') {
                    component.set("v.APIKey", records.API_Key); 
                    component.set("v.DataSyncMode", records.Data_Sync_Mode);
                
                    component.set("v.Entity", enti);
                    component.set("v.OldEntity", enti);
                }
                console.log('records.ListCustomField ===>'+records.ListCustomField);
                component.set("v.RecordType", records.Record_Type);
				component.set("v.SelectedRTSF2MLst", records.RTSFToMuster);                 
                component.set("v.MusterField", records.Muster_Field);
                component.set("v.SalesforceField", records.Salesforce_Field);
                component.set("v.SalesforceFieldLst", records.ListSalesforce_Field);
                component.set("v.ListCustomField", records.ListCustomField);
                
                component.set("v.FirstName", records.FirstName);     
                component.set("v.LastName", records.LastName);
                component.set("v.Prefix", records.Prefix);
                component.set("v.PrimaryEmail", records.PrimaryEmail);
                component.set("v.PhoneNumber", records.PhoneNumber);
                component.set("v.Address1", records.Address1);
                component.set("v.Address2", records.Address2);
                component.set("v.City", records.City);
                component.set("v.State", records.State);     
                component.set("v.ZIP", records.ZIP);
                component.set("v.EmailOptIn", records.EmailOptIn);
                component.set("v.TextOptIn", records.TextOptIn);
                component.set("v.Advocate", records.Advocate);
                
                component.set("v.PrefixLst", records.PrefixLst);
                component.set("v.FirstNameLst", records.FirstNameLst);
                component.set("v.LastNameLst", records.LastNameLst);
                component.set("v.PrimaryEmailLst", records.PrimaryEmailLst);
                component.set("v.PhoneNumberLst", records.PhoneNumberLst);
                component.set("v.Address1Lst", records.Address1Lst);
                component.set("v.Address2Lst", records.Address2Lst);
                component.set("v.CityLst", records.CityLst);
                component.set("v.StateLst", records.StateLst);
                component.set("v.ZipLst", records.ZipLst);
                component.set("v.EmailOptInLst", records.EmailOptInLst);
                component.set("v.TextOptInLst", records.TextOptInLst);
                component.set("v.AdvocateLst", records.AdvocateLst);
                component.set("v.RecordTypeLst", records.LstRT);
                component.set("v.MusterFieldLst", records.LstMusterField);                
                
                this.handleDataSyncMode(component);
            }
            else {
                console.log('Error ===>');
            }
        });
        $A.enqueueAction(action); 
    },    
    
    recordProcessIntoMetadata : function(component,event,helper) {               
        var M2SF = '';
        var SF2M = [];
        var mode = component.get('v.DataSyncMode');
        if(mode == 'Muster to Salesforce Only') {
            M2SF = component.get("v.RecordType");
            console.log('M2SF = '+M2SF);
            var lst = [];
            component.set("v.SelectedRTSF2MLst",lst)
        } 
        else if(mode == 'Salesforce to Muster Only') {
            SF2M = component.get("v.SelectedRTSF2MLst");
            console.log('SF2M = '+SF2M);
            component.set("v.RecordType",'');
        } else if(mode == 'Both Ways') {
            SF2M = component.get("v.SelectedRTSF2MLst");
            M2SF = component.get("v.RecordType");            
        } 
        
        console.log('M2SF ===== '+M2SF);
        console.log('SF2M ===== '+SF2M);
        
        var action = component.get("c.SaveMusterSetting");
        action.setParams({            
            "ApiKey": component.get('v.APIKey'),
            "RecordName" : "MusterData",
            "Entity" : component.get('v.Entity'),
            "MusterField" : component.get('v.MusterField'), 
            "SalesforceField" : component.get('v.SalesforceField'),
            "RecordType" : M2SF,
            "DataSyncMode" : component.get('v.DataSyncMode'),
            "Prefix" : component.get('v.Prefix'),
            "FirstName" : component.get('v.FirstName'),
            "LastName" : component.get('v.LastName'),
            "PrimaryEmail" : component.get('v.PrimaryEmail'),
            "PhoneNumber" : component.get('v.PhoneNumber'),
            "Address1" : component.get('v.Address1'),
            "Address2" : component.get('v.Address2'),
            "City" : component.get('v.City'),
            "State" : component.get('v.State'),
            "Zip" : component.get('v.ZIP'), 
            "EmailOptIn" : component.get('v.EmailOptIn'),
            "TextOptIn" : component.get('v.TextOptIn'),
            "Advocate" : component.get('v.Advocate'),
            "RecordTypeMToSF" : SF2M
        });        
        action.setCallback(this,function(response){
            var state = response.getState();
            if( state === "SUCCESS") {
                console.log( response.getReturnValue() );
                
                this.saveCustomField(component,event,helper);
                
               /* var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    mode: 'dismissible',
                    duration:'10000',
                    message: 'This is a required message',
                    messageTemplate: 'Your request has been submitted. Click {0}  to track the progress.',
                    messageTemplateData: [{
                        url: '/changemgmt/monitorDeploymentsDetails.apexp?asyncId=' + response.getReturnValue(),
                        label: 'Deployment Status',
                    }]
                });
                toastEvent.fire();*/
            }
            else  {
                var errors = response.getError();
                if (errors) {
                    if (errors[0] && errors[0].message) {
                        console.log("Error message: " +  errors[0].message);
                        toastEventError.setParams({
                            title : 'Error',
                            message: errors[0].message,
                            duration:'10000',
                            key: 'info_alt',
                            type: 'Error',
                            mode: 'dismissible'
                        });
                        toastEventError.fire(); 
                    }
                } else {
                    toastEventError.setParams({
                        title : 'Error',
                        message: "Unknown error",
                        duration:'10000',
                        key: 'info_alt',
                        type: 'Error',
                        mode: 'dismissible'
                    });
                    toastEventError.fire(); 
                    console.log("Unknown error");
                }
            }
        });        
        $A.enqueueAction(action);
    },
    
    saveCustomField : function(component,event,helper) {
        var ListCustomFieldForSave = [];
        var ListCustomField = component.get("v.ListCustomField");
        
        for(var k in ListCustomField) {
            var Id = ListCustomField[k].Id;
            var api = ListCustomField[k].Selected_SF_API_Name;
            
            ListCustomFieldForSave.push({'sObject':'Muster_Custom_Fields__c',
                                         'Id':Id,
                                         'SF_API_Name__c':api                                            
                                        }); 
        }
        var CustomFieldForSave  = JSON.stringify(ListCustomFieldForSave);        
        
        var action= component.get("c.SaveCustomFields");
        action.setParams({                        
            "ListCustomFieldForSave" : CustomFieldForSave
        });        
        action.setCallback(this,function(response){
            var state = response.getState();
            if( state === "SUCCESS") {
                console.log( response.getReturnValue() );                
                var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    title : 'SUCCESS',
                    type: 'SUCCESS',
                    mode: 'dismissible',
                    duration:'10000',
                    message: 'Muster settings saved successfully'                    
                });
                toastEvent.fire();
            }
            else  {
                var errors = response.getError();
                if (errors) {
                    if (errors[0] && errors[0].message) {
                        console.log("Error message: " +  errors[0].message);
                        toastEventError.setParams({
                            title : 'Error',
                            message: errors[0].message,
                            duration:'10000',
                            key: 'info_alt',
                            type: 'Error',
                            mode: 'dismissible'
                        });
                        toastEventError.fire(); 
                    }
                } else {
                    toastEventError.setParams({
                        title : 'Error',
                        message: "Unknown error",
                        duration:'10000',
                        key: 'info_alt',
                        type: 'Error',
                        mode: 'dismissible'
                    });
                    toastEventError.fire(); 
                    console.log("Unknown error");
                }
            }
        });        
        $A.enqueueAction(action);
    },
    
    handleDataSyncMode : function(component) {
        var mode = component.get('v.DataSyncMode');
        if(mode == 'Muster to Salesforce Only') {
            $A.util.addClass(component.find("SF2M"),"slds-hide");
            $A.util.removeClass(component.find("M2SF"),"slds-hide");
        } 
        else if(mode == 'Salesforce to Muster Only') {
            $A.util.removeClass(component.find("SF2M"),"slds-hide");
            $A.util.addClass(component.find("M2SF"),"slds-hide");
        } else if(mode == 'Both Ways') {
            $A.util.removeClass(component.find("SF2M"),"slds-hide");
            $A.util.removeClass(component.find("M2SF"),"slds-hide");
        } else {
            $A.util.addClass(component.find("SF2M"),"slds-hide");
            $A.util.addClass(component.find("M2SF"),"slds-hide");
        }
    },
})